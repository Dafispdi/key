body {
  background: #f3f6fb;
  font-family: 'Segoe UI', sans-serif;
}
input, button {
  font-size: 1rem;
}